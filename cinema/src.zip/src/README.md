
## Description

The application is a "Secure Cinema Search" portal. It's a simple Java Spring Boot application 

## How to Deploy

1.  Make sure you have Docker and Docker Compose installed.
2.  Navigate to the root directory of this challenge.
3.  Run the following command:

    ```sh
    docker-compose up --build -d
    ```

The challenge will be accessible at `http://localhost:8080`.

