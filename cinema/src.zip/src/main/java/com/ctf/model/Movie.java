package com.ctf.model;

public class Movie {
    private String title;
    private int year;
    private String description;

    public Movie(String title, int year, String description) {
        this.title = title;
        this.year = year;
        this.description = description;
    }

    // Getters are needed for Thymeleaf to access the fields
    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    public String getDescription() {
        return description;
    }
}