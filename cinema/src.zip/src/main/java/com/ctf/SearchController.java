package com.ctf;

import com.ctf.model.Movie;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.stream.Collectors;

@Controller
public class SearchController {

    private static final Logger logger = LogManager.getLogger(SearchController.class);

    private static final List<Movie> allMovies = List.of(
        new Movie("Titanic", 1997, "A seventeen-year-old aristocrat falls in love with a kind but poor artist aboard the luxurious, ill-fated R.M.S. Titanic."),
        new Movie("Bee Movie", 2007, "Barry B. Benson, a bee just graduated from college, is disillusioned at his lone career choice: making honey."),
        new Movie("The Minecraft Movie", 2025, "The malevolent Ender Dragon sets out on a path of destruction, prompting a young girl and her group of unlikely adventurers to set out to save the Overworld."),
        new Movie("The Matrix", 1999, "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers."),
        new Movie("Shrek", 2001, "A mean lord exiles fairytale creatures to the swamp of a grumpy ogre, who must go on a quest and rescue a princess for the lord in order to get his land back.")
    );

    @GetMapping("/")
    public String index(Model model) { // <-- Add the Model parameter
        model.addAttribute("searchPerformed", false); // <-- Initialize the variable
        return "index";
    }

    @PostMapping("/search")
    public String search(@RequestParam(required = false) String keyword, Model model) {
        logger.info("New search performed for keyword: " + keyword);

        model.addAttribute("searchPerformed", true); // <-- Move this line up

        if (keyword == null || keyword.trim().isEmpty()) {
            model.addAttribute("message", "Please enter a search term.");
        } else {
            String lowerCaseKeyword = keyword.toLowerCase();
            List<Movie> filteredMovies = allMovies.stream()
                    .filter(movie -> movie.getTitle().toLowerCase().contains(lowerCaseKeyword))
                    .collect(Collectors.toList());

            model.addAttribute("movies", filteredMovies);
        }
        
        return "index";
    }
}